function watchit(msg)
%function watchit(msg)
%
% Displays a warning message on the Matlab command line.  Used by 
% several Mass Univariate ERP Toolbox functions.
%

disp(' ');
disp('****************** Warning ******************');
disp(msg);
disp(' ');