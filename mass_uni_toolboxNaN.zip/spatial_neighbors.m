% spatial_neighbors() - Given a 2D matrix of t-scores, this function bundles
%                       neighboring above threshold t-scores into clusters
%                       and returns a 2D matrix of cluster assignments. For
%                       use with cluster-based permutation tests.
%
% Usage:
%  >>chan_hood=spatial_neighbors(chanlocs,max_dist);
%
% Inputs:
%   chanlocs - An EEGLAB chanlocs structure (e.g., EEG.chanlocs from an EEG
%              variable)
%   max_dist - All electrodes within max_dist of another electrode are
%              considered spatial neighbors.  Max_dist is in whatever units
%              your EEGLAB chanlocs coordinates are in.  If your chanlocs 
%              coordingates are on an idealized sphere with unit radius 
%              then you can convert max_dist into centimeters by measuring 
%              the circumference of a participant's head in centimeters and
%              using the following formulas:
%                 radius=circumference/(2*pi);
%                 radius*max_dist=max_dist in units of cm
%
% Outputs:
%   chan_hood - A symmetric binary matrix indicating which channels are
%               neighbors. If chan_hood(a,b)=1, then Channel A and Channel
%               B are nieghbors.
%
% Notes:
% -This function outputs an estimate of max_dist (in cm) on the command line
% by assuming a circumference of 56 cm and EEGLAB chanloc coordinates based 
% on a spherical head with unit radius.  It also summarizes the number of 
% neighbors per channel using basic measures of central tendency and 
% dispersion.
%
% Author:
% David Groppe
% Kutaslab, 5/2011

%%%%% Future Work %%%%%%
% -Perhaps allow users to select k-nearest neighbors instead of a distance
% threshold as suggested by Manish Saggar:
%   I would also advise to make sure the neighbor structure (created using
%   neighborselection()) is what you want. I had to learn this the hard
%   way, I had 88 channel data, initially, and we used 3D sensor locations
%   for each subject. The problem was that a single fixed number for
%   neighbor distance was not working for all the subjects. Besides, if
%   you pick one single number for defining neighbors, then some channels
%   have 3 neighbors, some have 5 or more (check using neighborselection()
%   func.). Lack of same number of neighbors can cause some channels more
%   likely to be in the cluster and some less (e.g. if minbanchan=2, then
%   a channel with 3 neighbors is less likely then a channel with 5
%   neighbors). Thus, I fixed the neighbor structure instead, giving each
%   channel exactly 4 neighbors (using 4 nearest neigbhors method).
% -Perhaps allow max_dist to be specified in centimeters

function chan_hood=spatial_neighbors(chanlocs,max_dist)

circumference=56; %very rough estimate based on the average circumference of 10 Kutaslab participants
max_dist_cm=max_dist*circumference/(2*pi);

fprintf('max_dist value of %g corresponds to an approximate distance of %.2f cm (assuming\n',max_dist,max_dist_cm);
fprintf('  a 56 cm radius head and that your electrode coordinates are based on an idealized\n');
fprintf('  spherical head with unit radius).\n');
    

n_chan=length(chanlocs);
chan_hood=zeros(n_chan,n_chan);
n_neighbors=zeros(1,n_chan);
for c=1:n_chan,
    coordA=[chanlocs(c).X chanlocs(c).Y chanlocs(c).Z];
    for d=c:n_chan,
        coordB=[chanlocs(d).X chanlocs(d).Y chanlocs(d).Z];
        dstnce=sqrt(sum([coordA-coordB].^2));
        if dstnce<=max_dist,
            chan_hood(c,d)=1;
            chan_hood(d,c)=1;
        end
    end
    n_neighbors(c)=sum(chan_hood(c,:))-1;
end

fprintf('Mean (SD) # of neighbors per channel: %.1f (%.1f)\n',mean(n_neighbors), ...
    std(n_neighbors));
fprintf('Median (semi-IQR) # of neighbors per channel: %.1f (%.1f)\n',median(n_neighbors), ...
    iqr(n_neighbors)/2);
fprintf('Min/max # of neighbors per channel: %d to %d\n',min(n_neighbors), ...
    max(n_neighbors));